  /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.artistry;

import javax.swing.JFrame;

/**
 *
 * @author User
 */
public class ArtisTry {

    public static void main(String[] args) {
        MainFrame main = new MainFrame();
        main.setTitle("ArtisTry");
        main.setExtendedState(JFrame.MAXIMIZED_BOTH);
        main.setDefaultCloseOperation(MainFrame.EXIT_ON_CLOSE);
        main.setLocationRelativeTo(null);
        main.setVisible(true);
        
    }
}

//icon size 250x100 px